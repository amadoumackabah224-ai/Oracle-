"""
Ces tests ne font AUCUNE requête réseau réelle : httpx.get est remplacé par
un double fidèle (monkeypatch) renvoyant un flux RSS statique. C'est
volontaire — un test qui dépend d'un vrai flux externe est fragile et peut
échouer pour des raisons indépendantes du code (flux temporairement
indisponible, changement de contenu). Le connecteur lui-même est conçu pour
être testé séparément en conditions réelles (voir README, section « Test
manuel du connecteur RSS »).
"""
import httpx
import pytest

from app.connectors import rss as rss_module
from app.models.source import Source
from app.services.ingestion import run_ingestion_for_source

SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel>
<title>Exemple</title><language>fr</language>
<item>
  <title>Premier article</title>
  <link>https://exemple.test/article-1</link>
  <guid>https://exemple.test/article-1</guid>
  <description>Resume du premier article.</description>
  <pubDate>Thu, 29 Oct 2026 10:00:00 GMT</pubDate>
</item>
<item>
  <title>Deuxieme article</title>
  <link>https://exemple.test/article-2</link>
  <guid>https://exemple.test/article-2</guid>
  <description>Resume du deuxieme article.</description>
  <pubDate>Thu, 29 Oct 2026 11:00:00 GMT</pubDate>
</item>
</channel></rss>""".encode("utf-8")


class _FakeResponse:
    def __init__(self, content: bytes, status_code: int = 200):
        self.content = content
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise httpx.HTTPStatusError("erreur", request=None, response=self)


@pytest.fixture()
def fake_feed(monkeypatch):
    monkeypatch.setattr(rss_module.httpx, "get", lambda *a, **k: _FakeResponse(SAMPLE_FEED))


def _make_source(db_session) -> Source:
    source = Source(name="Flux de test", source_type="rss", base_url="https://exemple.test/feed.xml")
    db_session.add(source)
    db_session.commit()
    db_session.refresh(source)
    return source


def test_ingestion_stores_new_items(db_session, fake_feed):
    source = _make_source(db_session)
    report = run_ingestion_for_source(db_session, source)
    assert report.success is True
    assert report.items_received == 2
    assert report.items_stored == 2
    assert report.items_duplicate == 0
    assert source.last_success_at is not None


def test_ingestion_deduplicates_on_second_run(db_session, fake_feed):
    source = _make_source(db_session)
    run_ingestion_for_source(db_session, source)
    report = run_ingestion_for_source(db_session, source)
    # Même flux collecté deux fois : rien de nouveau ne doit être stocké.
    assert report.items_stored == 0
    assert report.items_duplicate == 2


def test_ingestion_reports_failure_without_inventing_data(db_session, monkeypatch):
    def fail(*a, **k):
        raise httpx.ConnectError("DNS introuvable")

    monkeypatch.setattr(rss_module.httpx, "get", fail)
    source = _make_source(db_session)
    report = run_ingestion_for_source(db_session, source)
    assert report.success is False
    assert report.items_stored == 0
    assert "DNS introuvable" in (report.error_message or "")
    assert source.last_error_message is not None


def test_admin_test_source_requires_admin_role(client, db_session, fake_feed):
    # Le premier compte créé devient admin automatiquement (voir auth.py) :
    # on en crée donc un premier "à sacrifier" pour que le compte testé
    # ci-dessous reste un utilisateur normal, non admin.
    client.post(
        "/api/v1/auth/register", json={"email": "seed-admin@example.com", "password": "testpassword123"}
    )
    # Un utilisateur normal (non admin) ne doit pas pouvoir déclencher une collecte.
    client.post(
        "/api/v1/auth/register", json={"email": "user@example.com", "password": "testpassword123"}
    )
    login = client.post(
        "/api/v1/auth/login", json={"email": "user@example.com", "password": "testpassword123"}
    )
    token = login.json()["access_token"]
    source = _make_source(db_session)
    r = client.post(
        f"/api/v1/admin/sources/{source.id}/test",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 403

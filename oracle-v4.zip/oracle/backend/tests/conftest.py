"""
Les tests tournent sur une base SQLite en mémoire plutôt que sur PostgreSQL :
cela permet de les exécuter sans dépendance externe (utile en CI rapide).
Les migrations Alembic restent testées séparément contre un vrai PostgreSQL
(voir README — cette distinction doit rester explicite, SQLite et PostgreSQL
n'ont pas exactement le même comportement sur tous les types de colonnes).
"""
import os

os.environ.setdefault("SECRET_KEY", "test-secret-key-do-not-use-in-production")

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app

engine = create_engine(
    "sqlite:///:memory:",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=engine)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()

def _register_and_login(client, email: str, password: str = "testpassword123") -> str:
    r = client.post("/api/v1/auth/register", json={"email": email, "password": password})
    assert r.status_code == 201, r.text
    r = client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


def test_register_then_login_then_me(client):
    token = _register_and_login(client, "alice@example.com")
    r = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    assert r.json()["email"] == "alice@example.com"
    # le mot de passe haché ne doit jamais apparaître dans une réponse API
    assert "hashed_password" not in r.json()
    assert "password" not in r.json()


def test_cannot_register_same_email_twice(client):
    _register_and_login(client, "bob@example.com")
    r = client.post(
        "/api/v1/auth/register",
        json={"email": "bob@example.com", "password": "anotherpassword123"},
    )
    assert r.status_code == 409


def test_wrong_password_rejected(client):
    client.post(
        "/api/v1/auth/register",
        json={"email": "carol@example.com", "password": "correctpassword123"},
    )
    r = client.post(
        "/api/v1/auth/login",
        json={"email": "carol@example.com", "password": "wrongpassword"},
    )
    assert r.status_code == 401


def test_me_requires_token(client):
    r = client.get("/api/v1/auth/me")
    assert r.status_code == 401


def test_workspace_isolation_between_two_accounts(client):
    """
    Critère d'acceptation A du cahier des charges : isolation entre deux
    comptes testés. Alice crée un espace de travail ; Bob ne doit ni le voir
    dans sa liste, ni pouvoir consulter ses membres.
    """
    token_alice = _register_and_login(client, "alice2@example.com")
    token_bob = _register_and_login(client, "bob2@example.com")

    r = client.post(
        "/api/v1/workspaces",
        json={"name": "Espace d'Alice"},
        headers={"Authorization": f"Bearer {token_alice}"},
    )
    assert r.status_code == 201
    workspace_id = r.json()["id"]

    # Bob ne voit pas l'espace d'Alice dans sa propre liste
    r = client.get("/api/v1/workspaces", headers={"Authorization": f"Bearer {token_bob}"})
    assert r.status_code == 200
    assert all(w["id"] != workspace_id for w in r.json())

    # Bob ne peut pas consulter les membres de l'espace d'Alice
    r = client.get(
        f"/api/v1/workspaces/{workspace_id}/members",
        headers={"Authorization": f"Bearer {token_bob}"},
    )
    assert r.status_code == 404

    # Alice, elle, le peut
    r = client.get(
        f"/api/v1/workspaces/{workspace_id}/members",
        headers={"Authorization": f"Bearer {token_alice}"},
    )
    assert r.status_code == 200
    assert len(r.json()) == 1

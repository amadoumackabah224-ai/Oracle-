"""
Test manuel du connecteur RSS contre un vrai flux, en dehors de la suite
pytest (qui elle reste volontairement hors-réseau — voir tests/test_ingestion.py).

Usage :
    python scripts/test_connector.py https://www.lemonde.fr/rss/une.xml

Ce script ne modifie aucune base de données ; il affiche seulement ce que
le connecteur a réellement récupéré, pour vérifier à l'œil que le flux
choisi est valide avant de l'enregistrer comme source.
"""
import sys

from app.connectors.rss import fetch_rss


def main() -> None:
    if len(sys.argv) != 2:
        print("Usage : python scripts/test_connector.py <url_du_flux_rss>")
        sys.exit(1)

    result = fetch_rss(sys.argv[1])

    if not result.success:
        print(f"ÉCHEC : {result.error_message}")
        sys.exit(1)

    print(f"Succès — {len(result.items)} éléments récupérés :\n")
    for item in result.items[:10]:
        print(f"- {item.title}")
        print(f"  {item.canonical_url}")
        print(f"  publié : {item.published_at}")
        print()


if __name__ == "__main__":
    main()

"""
Dépendances FastAPI réutilisées par les routes protégées.

Règle du cahier des charges (9.1) : « Masquer un bouton dans l'interface ne
constitue pas un contrôle d'accès. » Toute vérification de permission doit
donc avoir lieu ici, côté serveur, et non dans le frontend.
"""
import uuid

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.core.security import decode_access_token
from app.db.session import get_db
from app.models.user import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


def get_current_user(
    token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)
) -> User:
    credentials_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Identifiants invalides ou expirés.",
        headers={"WWW-Authenticate": "Bearer"},
    )
    user_id = decode_access_token(token)
    if user_id is None:
        raise credentials_error
    try:
        user = db.get(User, uuid.UUID(user_id))
    except ValueError:
        raise credentials_error
    if user is None or user.status != "active":
        raise credentials_error
    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cette opération nécessite un rôle administrateur.",
        )
    return user

import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.models.workspace import Workspace, WorkspaceMember

router = APIRouter(prefix="/workspaces", tags=["workspaces"])


class WorkspaceCreate(BaseModel):
    name: str


class WorkspaceOut(BaseModel):
    id: uuid.UUID
    name: str
    owner_user_id: uuid.UUID

    class Config:
        from_attributes = True


@router.get("", response_model=list[WorkspaceOut])
def list_my_workspaces(
    db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
) -> list[Workspace]:
    """
    Ne retourne QUE les espaces de travail dont l'utilisateur est membre —
    c'est le contrôle d'isolation exigé en 9.2, appliqué ici côté requête.
    """
    return (
        db.query(Workspace)
        .join(WorkspaceMember, WorkspaceMember.workspace_id == Workspace.id)
        .filter(WorkspaceMember.user_id == current_user.id)
        .all()
    )


@router.post("", response_model=WorkspaceOut, status_code=status.HTTP_201_CREATED)
def create_workspace(
    payload: WorkspaceCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> Workspace:
    workspace = Workspace(name=payload.name, owner_user_id=current_user.id)
    db.add(workspace)
    db.flush()  # obtenir workspace.id avant le commit
    db.add(WorkspaceMember(workspace_id=workspace.id, user_id=current_user.id, role="owner"))
    db.commit()
    db.refresh(workspace)
    return workspace


@router.get("/{workspace_id}/members")
def list_members(
    workspace_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    membership = (
        db.query(WorkspaceMember)
        .filter(
            WorkspaceMember.workspace_id == workspace_id,
            WorkspaceMember.user_id == current_user.id,
        )
        .first()
    )
    if membership is None:
        # 404 plutôt que 403 : ne pas confirmer l'existence d'une ressource
        # à laquelle l'utilisateur n'a pas accès.
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Espace de travail introuvable.")
    members = db.query(WorkspaceMember).filter(WorkspaceMember.workspace_id == workspace_id).all()
    return [{"user_id": m.user_id, "role": m.role} for m in members]

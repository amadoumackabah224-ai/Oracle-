import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.deps import require_admin
from app.db.session import get_db
from app.models.source import Source
from app.services.ingestion import IngestionReport, run_ingestion_for_source

router = APIRouter(prefix="/admin/sources", tags=["admin"])


class SourceCreate(BaseModel):
    name: str
    source_type: str  # "rss" en Phase 2
    base_url: str
    license_name: str | None = None
    language_codes: str | None = None


class SourceOut(BaseModel):
    id: uuid.UUID
    name: str
    source_type: str
    base_url: str
    enabled: bool
    last_success_at: datetime | None
    last_error_at: datetime | None
    last_error_message: str | None

    class Config:
        from_attributes = True


@router.get("", response_model=list[SourceOut])
def list_sources(db: Session = Depends(get_db), _=Depends(require_admin)):
    return db.query(Source).all()


@router.post("", response_model=SourceOut, status_code=status.HTTP_201_CREATED)
def create_source(payload: SourceCreate, db: Session = Depends(get_db), _=Depends(require_admin)):
    source = Source(**payload.model_dump())
    db.add(source)
    db.commit()
    db.refresh(source)
    return source


@router.post("/{source_id}/test")
def test_source(source_id: uuid.UUID, db: Session = Depends(get_db), _=Depends(require_admin)) -> IngestionReport:
    """
    Déclenche une collecte réelle immédiate et retourne un rapport factuel —
    jamais un simple "ok" : nombre d'éléments reçus, stockés, dupliqués,
    rejetés, ou le message d'erreur exact en cas d'échec (section 5.2 :
    état opérationnel, dernier succès, dernière erreur).
    """
    source = db.get(Source, source_id)
    if source is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Source introuvable.")
    return run_ingestion_for_source(db, source)

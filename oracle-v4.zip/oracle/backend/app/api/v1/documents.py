import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.session import get_db
from app.models.document import Document
from app.models.source import Source

router = APIRouter(prefix="/documents", tags=["documents"])


class DocumentOut(BaseModel):
    id: uuid.UUID
    source_name: str
    canonical_url: str
    title: str
    language_code: str | None
    published_at: datetime | None
    collected_at: datetime


class DocumentSearchResponse(BaseModel):
    items: list[DocumentOut]
    total: int
    page: int
    page_size: int


@router.get("", response_model=DocumentSearchResponse)
def search_documents(
    q: str | None = Query(None, description="Recherche textuelle dans le titre"),
    source_id: uuid.UUID | None = None,
    language_code: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    _=Depends(get_current_user),
) -> DocumentSearchResponse:
    """
    Recherche filtrée des documents collectés, avec pagination obligatoire
    (section 7.7) et la source citée pour chaque résultat — un document
    sans origine traçable n'est jamais affiché comme un fait.
    """
    query = db.query(Document, Source.name).join(Source, Document.source_id == Source.id)

    if q:
        query = query.filter(Document.title.ilike(f"%{q}%"))
    if source_id:
        query = query.filter(Document.source_id == source_id)
    if language_code:
        query = query.filter(Document.language_code == language_code)

    total = query.count()
    rows = (
        query.order_by(Document.published_at.desc().nulls_last())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    items = [
        DocumentOut(
            id=doc.id,
            source_name=source_name,
            canonical_url=doc.canonical_url,
            title=doc.title,
            language_code=doc.language_code,
            published_at=doc.published_at,
            collected_at=doc.collected_at,
        )
        for doc, source_name in rows
    ]
    return DocumentSearchResponse(items=items, total=total, page=page, page_size=page_size)

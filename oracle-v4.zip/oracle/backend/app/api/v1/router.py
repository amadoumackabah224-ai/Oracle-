from fastapi import APIRouter

from app.api.v1 import admin_sources, auth, documents, workspaces

api_router = APIRouter()
api_router.include_router(auth.router)
api_router.include_router(workspaces.router)
api_router.include_router(documents.router)
api_router.include_router(admin_sources.router)

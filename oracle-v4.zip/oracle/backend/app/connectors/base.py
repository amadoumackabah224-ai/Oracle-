"""
Contrat commun à tout connecteur (section 5.2 du cahier des charges).

Un connecteur ne doit JAMAIS lever d'exception non gérée vers l'appelant :
une source indisponible est une situation normale et attendue, pas une
panne de l'application. Il doit retourner un ConnectorResult explicite,
que le pipeline d'ingestion peut ensuite journaliser sans inventer de
données manquantes.
"""
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class RawItem:
    """Un élément brut récupéré depuis une source, avant normalisation."""
    external_id: str | None
    canonical_url: str
    title: str
    content_text: str | None
    language_code: str | None
    published_at: datetime | None


@dataclass
class ConnectorResult:
    success: bool
    items: list[RawItem] = field(default_factory=list)
    error_message: str | None = None

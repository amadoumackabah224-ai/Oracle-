"""
Connecteur RSS — premier connecteur réel d'ORACLE.

Choisi en premier car : aucune clé API requise, conditions de licence
généralement claires (un flux RSS public est publié pour être lu par des
agrégateurs), et format normalisé. C'est la source la plus simple pour
prouver le pipeline de bout en bout avant d'ajouter des sources plus
complexes (GDELT, Banque mondiale) qui suivront exactement le même contrat.
"""
import hashlib
from datetime import datetime, timezone

import feedparser
import httpx

from app.connectors.base import ConnectorResult, RawItem

USER_AGENT = "ORACLE/0.1 (+veille automatisee; contact: admin@oracle.example)"


def fetch_rss(feed_url: str, timeout_seconds: float = 10.0) -> ConnectorResult:
    """
    Récupère et parse un flux RSS/Atom. Ne lève jamais d'exception :
    tout échec (réseau, flux malformé) est retourné dans ConnectorResult.
    """
    try:
        response = httpx.get(
            feed_url,
            timeout=timeout_seconds,
            headers={"User-Agent": USER_AGENT},
            follow_redirects=True,
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        return ConnectorResult(success=False, error_message=f"Échec de la requête HTTP : {exc}")

    parsed = feedparser.parse(response.content)
    if parsed.bozo and not parsed.entries:
        # bozo=1 signale un flux malformé ; si en plus aucune entrée n'a pu
        # être extraite, on considère l'échec plutôt que de retourner une
        # liste vide silencieuse qui serait indiscernable d'un flux à jour.
        return ConnectorResult(
            success=False, error_message=f"Flux illisible : {parsed.get('bozo_exception')}"
        )

    items: list[RawItem] = []
    for entry in parsed.entries:
        published_at = None
        if getattr(entry, "published_parsed", None):
            published_at = datetime(*entry.published_parsed[:6], tzinfo=timezone.utc)

        items.append(
            RawItem(
                external_id=entry.get("id") or entry.get("link"),
                canonical_url=entry.get("link", ""),
                title=entry.get("title", "").strip(),
                content_text=(entry.get("summary") or entry.get("description") or "").strip() or None,
                language_code=parsed.feed.get("language"),
                published_at=published_at,
            )
        )

    return ConnectorResult(success=True, items=items)


def compute_content_hash(title: str, content_text: str | None) -> str:
    """
    Empreinte utilisée pour la déduplication (étape 4, section 5.3).
    Basée sur le titre + le contenu normalisés, pas sur l'URL seule :
    une même URL republiée avec un contenu différent doit être détectée
    comme un élément distinct, pas écrasée silencieusement.
    """
    basis = f"{title.strip().lower()}|{(content_text or '').strip().lower()}"
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()

"""
Pipeline d'ingestion — section 5.3 du cahier des charges.

Étapes implémentées pour la Phase 2 (RSS) :
  1. Vérifier la réponse de la source       -> ConnectorResult.success
  2. Valider le format                      -> RawItem déjà structuré
  3. Normaliser dates/langues/identifiants  -> fait dans le connecteur
  4. Calculer une empreinte (déduplication) -> compute_content_hash
  5. Enregistrer la source originale        -> Document.canonical_url
  9. Enregistrer les résultats du traitement -> IngestionReport retourné

Ce module ne contacte jamais un fournisseur d'IA et n'invente aucune
donnée : un item sans titre exploitable est simplement ignoré et compté,
jamais complété par une valeur inventée.
"""
from dataclasses import dataclass, field
from datetime import datetime, timezone

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.connectors.base import ConnectorResult
from app.connectors.rss import compute_content_hash, fetch_rss
from app.models.document import Document
from app.models.source import Source


@dataclass
class IngestionReport:
    source_id: str
    success: bool
    items_received: int = 0
    items_stored: int = 0
    items_duplicate: int = 0
    items_rejected: int = 0
    error_message: str | None = None
    finished_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


def run_ingestion_for_source(db: Session, source: Source) -> IngestionReport:
    if source.source_type != "rss":
        return IngestionReport(
            source_id=str(source.id),
            success=False,
            error_message=f"Type de source non supporté en Phase 2 : {source.source_type}",
        )

    result: ConnectorResult = fetch_rss(source.base_url)

    if not result.success:
        source.last_error_at = datetime.now(timezone.utc)
        source.last_error_message = result.error_message
        db.commit()
        return IngestionReport(source_id=str(source.id), success=False, error_message=result.error_message)

    stored = duplicate = rejected = 0

    for item in result.items:
        if not item.title or not item.canonical_url:
            rejected += 1
            continue

        content_hash = compute_content_hash(item.title, item.content_text)
        doc = Document(
            source_id=source.id,
            canonical_url=item.canonical_url,
            external_id=item.external_id,
            title=item.title,
            content_text=item.content_text,
            language_code=item.language_code,
            published_at=item.published_at,
            collected_at=datetime.now(timezone.utc),
            content_hash=content_hash,
        )
        db.add(doc)
        try:
            db.flush()  # déclenche la contrainte d'unicité sans committer
            stored += 1
        except IntegrityError:
            db.rollback()
            duplicate += 1

    source.last_success_at = datetime.now(timezone.utc)
    source.last_error_message = None
    db.commit()

    return IngestionReport(
        source_id=str(source.id),
        success=True,
        items_received=len(result.items),
        items_stored=stored,
        items_duplicate=duplicate,
        items_rejected=rejected,
    )

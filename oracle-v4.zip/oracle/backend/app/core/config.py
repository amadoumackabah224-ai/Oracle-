"""
Configuration centralisée de l'application.

Toutes les valeurs sensibles (clé secrète, identifiants de base de données)
proviennent des variables d'environnement — jamais de valeurs codées en dur
dans le dépôt. Voir .env.example pour la liste des variables attendues.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    PROJECT_NAME: str = "ORACLE API"
    API_V1_PREFIX: str = "/api/v1"

    # Base de données
    DATABASE_URL: str = "postgresql+psycopg2://oracle:oracle@localhost:5432/oracle"

    # Authentification
    SECRET_KEY: str  # obligatoire — aucune valeur par défaut pour un secret
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24h, à ajuster en production

    # CORS — origines autorisées pour le frontend
    CORS_ORIGINS: list[str] = ["http://localhost:5173"]

    ENVIRONMENT: str = "development"


settings = Settings()

"""
Importer ce package (`import app.models`) enregistre toutes les classes
ORM sur Base.metadata, sans jamais créer d'import circulaire : ce fichier
importe les modèles, les modèles importent Base — jamais l'inverse.
Utilisé par Alembic (alembic/env.py) pour l'autogénération des migrations.
"""
from app.models.user import User  # noqa: F401
from app.models.workspace import Workspace, WorkspaceMember  # noqa: F401
from app.models.source import Source  # noqa: F401
from app.models.document import Document  # noqa: F401

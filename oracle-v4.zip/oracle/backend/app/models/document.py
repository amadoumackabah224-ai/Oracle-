import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class Document(Base):
    """
    Table `documents` — section 6.2.

    `content_hash` est l'empreinte utilisée pour la déduplication (étape 4
    du pipeline, section 5.3) : un même article republié ou récupéré deux
    fois par erreur ne doit jamais apparaître en double. La contrainte
    d'unicité est posée sur (source_id, content_hash) : une même empreinte
    peut légitimement réapparaître sur une AUTRE source (republication
    autorisée), mais pas deux fois depuis la même source.
    """
    __tablename__ = "documents"
    __table_args__ = (UniqueConstraint("source_id", "content_hash", name="uq_document_source_hash"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    source_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sources.id"), nullable=False)
    canonical_url: Mapped[str] = mapped_column(String, nullable=False)
    external_id: Mapped[str | None] = mapped_column(String, nullable=True)
    title: Mapped[str] = mapped_column(String, nullable=False)
    content_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    language_code: Mapped[str | None] = mapped_column(String, nullable=True)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    collected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    content_hash: Mapped[str] = mapped_column(String, nullable=False, index=True)

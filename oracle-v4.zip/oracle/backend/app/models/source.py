import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class Source(Base):
    """
    Table `sources` — section 6.2. Un connecteur = une ligne ici.
    Les secrets éventuels (clé API d'une source payante) ne sont JAMAIS
    stockés dans cette table — voir app/core/config.py pour les secrets,
    chargés depuis l'environnement.
    """
    __tablename__ = "sources"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String, nullable=False)
    source_type: Mapped[str] = mapped_column(String, nullable=False)  # "rss", "api", ...
    base_url: Mapped[str] = mapped_column(String, nullable=False)
    license_name: Mapped[str | None] = mapped_column(String, nullable=True)
    language_codes: Mapped[str | None] = mapped_column(String, nullable=True)  # ex: "fr,en"
    poll_interval_seconds: Mapped[int] = mapped_column(Integer, default=3600)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_success_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error_message: Mapped[str | None] = mapped_column(String, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

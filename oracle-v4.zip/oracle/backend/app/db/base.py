from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """
    Base déclarative partagée par tous les modèles ORM.

    IMPORTANT : ce fichier ne doit JAMAIS importer un modèle (app.models.*).
    Chaque modèle fait `from app.db.base import Base` — si ce fichier
    importait un modèle en retour, et qu'un autre module importe ce modèle
    en premier (avant que ce fichier soit chargé), Python se retrouve à
    essayer de lire une classe sur un module encore à moitié chargé →
    ImportError "partially initialized module" (bug réellement rencontré
    lors du premier déploiement). La liste complète des modèles, pour
    Alembic, vit séparément dans app/models/__init__.py.
    """
    pass

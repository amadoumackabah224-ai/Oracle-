import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { api } from "../api/client";

type Workspace = { id: string; name: string };

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [newName, setNewName] = useState("");

  async function refresh() {
    setWorkspaces((await api.listWorkspaces()) as Workspace[]);
  }

  useEffect(() => {
    refresh();
  }, []);

  async function createWorkspace() {
    if (!newName.trim()) return;
    await api.createWorkspace(newName.trim());
    setNewName("");
    refresh();
  }

  return (
    <div className="dash">
      <header>
        <h1>ORACLE</h1>
        <div>
          <span>{user?.display_name || user?.email}</span>
          <button onClick={logout}>Se déconnecter</button>
        </div>
      </header>
      <main>
        <p className="notice">
          Phase 1 — fondations : authentification et espaces de travail réellement connectés à l'API.
          Les modules de veille, prévisions et alertes du cahier des charges arrivent en Phase 2+.
        </p>
        <section>
          <h2>Vos espaces de travail</h2>
          {workspaces.length === 0 && <p>Aucun espace de travail pour l'instant.</p>}
          <ul>
            {workspaces.map((w) => (
              <li key={w.id}>{w.name}</li>
            ))}
          </ul>
          <div className="newws">
            <input
              placeholder="Nom du nouvel espace de travail"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
            />
            <button onClick={createWorkspace}>Créer</button>
          </div>
        </section>
      </main>
    </div>
  );
}

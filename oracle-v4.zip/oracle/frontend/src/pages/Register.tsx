import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api, ApiError } from "../api/client";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await api.register(email, password, displayName || undefined);
      await login(email, password);
      navigate("/dashboard");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Inscription impossible.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="authpage">
      <form className="authcard" onSubmit={onSubmit}>
        <h1>ORACLE</h1>
        <p className="sub">Créer un compte</p>
        {error && <div className="err">{error}</div>}
        <label>Nom affiché
          <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
        </label>
        <label>E-mail
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </label>
        <label>Mot de passe (8 caractères minimum)
          <input type="password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required />
        </label>
        <button type="submit" disabled={busy}>{busy ? "Création…" : "Créer mon compte"}</button>
        <p className="switch">Déjà un compte ? <Link to="/login">Se connecter</Link></p>
      </form>
    </div>
  );
}

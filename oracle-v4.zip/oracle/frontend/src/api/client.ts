// En développement local, VITE_API_BASE est vide et "/api/v1" passe par le
// proxy de vite.config.ts vers http://localhost:8000. En production, Render
// injecte VITE_API_BASE à la construction (ex: https://oracle-backend-v3.onrender.com)
// puisque le frontend et le backend sont deux services séparés, sur deux
// domaines différents.
const BASE = `${import.meta.env.VITE_API_BASE ?? ""}/api/v1`;

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem("oracle_token");
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string> | undefined),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${BASE}${path}`, { ...options, headers });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail ?? detail;
    } catch {
      /* réponse sans corps JSON exploitable */
    }
    throw new ApiError(res.status, detail);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export const api = {
  register: (email: string, password: string, display_name?: string) =>
    request("/auth/register", { method: "POST", body: JSON.stringify({ email, password, display_name }) }),
  login: (email: string, password: string) =>
    request<{ access_token: string }>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),
  me: () => request("/auth/me"),
  listWorkspaces: () => request("/workspaces"),
  createWorkspace: (name: string) =>
    request("/workspaces", { method: "POST", body: JSON.stringify({ name }) }),
};

# ORACLE — Phases 1 et 2 : Fondations + Collecte réelle

Ce dépôt contient les **Phases 1 et 2** du plan d'implémentation défini
dans le cahier des charges ORACLE v1.0 (section 12). Les phases suivantes
(assistant IA, signaux, prévisions, commercialisation) ne sont **pas
encore implémentées** — voir « Prochaine étape » en bas de page.

## Phase 2 — ce qui a été ajouté

- Un connecteur RSS réel (`app/connectors/rss.py`), sans clé API requise,
  qui ne lève jamais d'exception non gérée : toute panne réseau ou flux
  malformé revient sous forme de `ConnectorResult` explicite.
- Un pipeline d'ingestion (`app/services/ingestion.py`) : récupération,
  validation, déduplication par empreinte de contenu, stockage, rapport
  factuel (reçus / stockés / dupliqués / rejetés) — jamais de donnée
  inventée en cas d'échec partiel.
- Tables `sources` et `documents` (migration `0002`).
- `POST /api/v1/admin/sources/{id}/test` — déclenche une collecte réelle
  et retourne le rapport, réservé aux administrateurs.
- `GET /api/v1/documents` — recherche filtrée (texte, source, langue),
  paginée, avec la source citée pour chaque résultat.
- Règle ajoutée : le tout premier compte créé sur une base vierge devient
  administrateur automatiquement (sinon aucune route d'administration ne
  serait jamais accessible). **Limite connue** : en cas d'inscriptions
  strictement simultanées sur une base vide, une condition de course
  existe. Sans conséquence pour un déploiement normal, mais à corriger
  avant un lancement public (ex. verrou transactionnel ou compte admin
  créé explicitement par script de démarrage).

### Statut des tests — Phase 2

Comme pour la Phase 1 : écrits, **non exécutés** dans l'environnement où
ce code a été généré (pas d'accès réseau pour installer les dépendances).
`tests/test_ingestion.py` simule la réponse HTTP d'un flux RSS (pas de
vraie requête réseau dans les tests, pour qu'ils restent reproductibles)
et couvre : stockage de nouveaux éléments, déduplication sur une seconde
collecte identique, gestion d'un échec réseau sans invention de données,
et contrôle d'accès admin sur la route de test de connecteur.

### Tester le connecteur contre un vrai flux

```bash
cd backend
python scripts/test_connector.py https://www.lemonde.fr/rss/une.xml
```

Ce script n'écrit rien en base ; il sert à vérifier à l'œil qu'un flux
est exploitable avant de l'enregistrer comme source via l'API.

## État réel — à lire avant de croire quoi que ce soit d'autre

Conformément à la règle 15.4 du cahier des charges, voici la distinction
exacte entre ce qui a été fait et ce qui a été vérifié :

| Étape | Statut |
|---|---|
| Code écrit | ✅ Backend (FastAPI), frontend (React) et pipeline de collecte (Phases 1+2) |
| Migrations de base de données écrites | ✅ `0001_initial.py`, `0002_sources_documents.py` |
| Tests automatisés écrits | ✅ `test_auth.py` (6 tests) + `test_ingestion.py` (5 tests) |
| Tests exécutés | ❌ **Non exécutés.** L'environnement dans lequel ce code a été généré n'a pas d'accès réseau pour installer les dépendances Python/Node. Tu dois les lancer toi-même (voir ci-dessous) avant de considérer quoi que ce soit comme fonctionnel. |
| Connecteur RSS testé contre un vrai flux | ❌ Non testé dans cet environnement, pour la même raison. |
| Déploiement | ❌ Rien n'est déployé. Ce dépôt n'a jamais tourné en dehors de l'écriture du code. |

**Ne considère aucune fonctionnalité comme acquise tant que tu n'as pas
exécuté les commandes ci-dessous et vu les résultats toi-même.**

## Ce qui est implémenté (Phase 1)

- Inscription / connexion / consultation du profil (`/api/v1/auth/*`), mots
  de passe hachés avec bcrypt, jetons JWT.
- Création et consultation d'espaces de travail, avec isolation vérifiée
  **côté serveur** à chaque requête (table `workspace_members`) — pas
  seulement dans l'interface.
- Schéma de base de données versionné (Alembic), conforme aux tables
  `users`, `workspaces`, `workspace_members` de la section 6.2.
- Frontend React connecté aux vraies routes de l'API (aucune donnée
  simulée) : page de connexion, d'inscription, tableau de bord minimal.
- Permissions vérifiées côté serveur (`require_admin`, vérification
  d'appartenance à un workspace) — pas de contrôle d'accès reposant sur
  l'affichage ou non d'un bouton.

## Ce qui n'est PAS encore implémenté

Tout le reste du cahier des charges : connecteurs de données, World Radar,
Oracle Assistant, Signal Intelligence, Future Engine, Opportunity Hunter,
Scenario Lab, alertes, facturation, administration avancée. C'est la
Phase 2 et au-delà (section 12).

## Lancer le projet en local

### Prérequis
- Docker et Docker Compose (le plus simple), **ou** Python 3.12+ et
  Node.js 20+ installés localement.
- Aucune clé API externe n'est nécessaire pour la Phase 1.

### Avec Docker (recommandé)

```bash
cp backend/.env.example backend/.env
# Éditer backend/.env et remplacer SECRET_KEY par une valeur aléatoire longue
# (ex: python3 -c "import secrets; print(secrets.token_urlsafe(32))")

docker compose up --build
```

Puis, dans un autre terminal, applique la migration :

```bash
docker compose exec backend alembic upgrade head
```

L'API est disponible sur http://localhost:8000 (documentation interactive
sur http://localhost:8000/docs).

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Puis ouvre http://localhost:5173.

### Sans Docker

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # éditer SECRET_KEY et DATABASE_URL

# Nécessite un PostgreSQL local sur l'URL indiquée dans .env
alembic upgrade head
uvicorn app.main:app --reload
```

### Exécuter les tests

```bash
cd backend
pip install -r requirements.txt
pytest -v
```

Les tests tournent sur une base SQLite en mémoire (aucun PostgreSQL requis
pour les tests unitaires) et couvrent :
- inscription, connexion, consultation du profil ;
- rejet d'un e-mail déjà utilisé ;
- rejet d'un mauvais mot de passe ;
- rejet d'un accès sans jeton ;
- **isolation entre deux comptes** sur les espaces de travail (critère
  d'acceptation A du cahier des charges).

Lance-les et vérifie toi-même qu'ils passent — c'est la seule preuve qui
compte, pas cette description.

## Prochaine étape (Phase 3 — Assistant IA)

Selon la section 12 du cahier des charges : couche d'abstraction vers un
fournisseur de modèle de langage, recherche documentaire sur les
`documents` déjà collectés (le connecteur RSS de la Phase 2 lui fournit
sa première matière), gestion des conversations, réponses sourcées avec
citation obligatoire, contrôle des coûts et des quotas. Critère de
sortie : l'assistant répond à un jeu de questions de référence, cite des
sources vérifiables et signale correctement les limites des informations
disponibles.

D'autres connecteurs (GDELT, Banque mondiale, FMI) peuvent aussi être
ajoutés en parallèle : ils suivent exactement le même contrat
(`app/connectors/base.py`) que le connecteur RSS, donc le même pipeline
d'ingestion les prend en charge sans modification majeure.

## Pousser ce code sur Git

```bash
git init
git add .
git commit -m "Phase 1 — fondations : auth, workspaces, schéma de base de données"
git remote add origin <url-de-ton-depot>
git push -u origin main
```

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Base déclarative partagée par tous les modèles ORM."""
    pass


# Importer tous les modèles ici pour qu'Alembic les détecte lors de
# l'autogénération des migrations.
from app.models.user import User  # noqa: E402,F401
from app.models.workspace import Workspace, WorkspaceMember  # noqa: E402,F401
from app.models.source import Source  # noqa: E402,F401
from app.models.document import Document  # noqa: E402,F401
